# دفتر مدرسه

نسخه اندروید WebView از نسخه تأییدشده وب.

## ساخت APK
مخزن را در GitHub قرار بده. با هر Push به شاخه main یا اجرای دستی Workflow با نام `Build Daftar Madrese APK`، فایل APK ساخته می‌شود.

فایل خروجی در بخش Actions و قسمت Artifacts با نام `Daftar-Madrese-APK` قرار می‌گیرد.
