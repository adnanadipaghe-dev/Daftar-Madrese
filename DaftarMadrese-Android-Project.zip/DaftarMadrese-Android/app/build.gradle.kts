plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.daftar.madrese"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.daftar.madrese"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
